# Loan-Approval-Prediction-using-Machine-Learning
Using Machine Learning with Python to ease Bank work and predict whether the candidate’s profile is relevant or not using key features like Marital Status, Education, Applicant Income, Credit History, etc.

![image](https://github.com/user-attachments/assets/cd928923-52a5-4e5a-8245-9f7549d03e69)
![image](https://github.com/user-attachments/assets/13589f4f-f5d1-4d65-b930-a8690b832dde)
![image](https://github.com/user-attachments/assets/aa45f402-36c7-417e-ac83-8a99b61e89b5)

